/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entitys;

/**
 *
 * @author Omar
 */
class HelpMethod {
        public static boolean CanMoveHere(float x, float y, int width, int height, int[][] lvlData) {
        // تحقق من التصادم مع المستوى
        // يجب استبدال هذا بالتحقق الفعلي بناءً على بيانات المستوى
        return true;  // يجب استبداله بالتحقق الفعلي
    }

    public static boolean IsOnGround(float x, float y, int width, int height, int[][] lvlData) {
        // تحقق من أن اللاعب على الأرض
        // يجب استبدال هذا بالتحقق الفعلي بناءً على بيانات المستوى
        // على سبيل المثال، يمكن التحقق من النقطة تحت اللاعب
        return true;  // يجب استبداله بالتحقق الفعلي
    }
}
